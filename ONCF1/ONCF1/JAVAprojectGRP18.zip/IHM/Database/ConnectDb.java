package Database;

public class ConnectDb {
    public static void main(String[] args) {
        Database C=new Database(1);
       
        
    }
   

}
