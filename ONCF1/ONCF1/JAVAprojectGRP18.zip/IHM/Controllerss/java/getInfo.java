package Controllerss.java;
import IHM1.*;

public class getInfo {
    

}
