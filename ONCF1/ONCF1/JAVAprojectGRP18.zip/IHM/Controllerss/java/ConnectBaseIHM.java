package Controllerss.java;

public class ConnectBaseIHM {
    

}
