package IHM1;


import javax.swing.JLabel;
import javax.swing.JPanel;



public class Jlabelss {
    public Jlabelss(JPanel pi,String text,String statut){
        JLabel r=new JLabel(text);
       
        pi.add(r,statut);


    }
    
}
